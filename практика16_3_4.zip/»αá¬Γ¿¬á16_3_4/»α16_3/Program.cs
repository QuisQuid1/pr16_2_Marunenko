﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace пр16_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try 
            {
                if (File.Exists("text.txt"))
                {
                    string[] lines;
                    lines = File.ReadAllLines("text.txt");
                    List<double> numbers = new List<double>();
                    foreach (string line in lines)
                    {
                        string[] p = line.Split(';');
                        foreach (string pr in p)
                        {
                            if (double.TryParse(pr, out double number))
                            {
                                numbers.Add(number);
                            }
                        }
                    }
                    var f = numbers
                    .GroupBy(x => x)
                    .ToDictionary(g => g.Key, g => g.Count());
                    Console.WriteLine("Число\tЧастота");
                    Console.WriteLine("-------------------");
                    foreach (var item in f)
                    {
                        Console.WriteLine($"{item.Key}\t{item.Value}");
                    }
                }
                else
                {
                    Console.WriteLine("Файл не существует.");
                }
                if (File.Exists("text.txt"))
                {
                    string[] lines;
                    lines = File.ReadAllLines("text.txt");
                    List<double> numbers = new List<double>();
                    foreach (string line in lines)
                    {
                        string[] p = line.Split(';');
                        foreach (string pr in p)
                        {
                            if (double.TryParse(pr, out double number))
                            {
                                numbers.Add(number);
                            }
                        }
                    }
                    var f = numbers
                    .GroupBy(x => x)
                    .ToDictionary(g => g.Key, g => g.Count());
                    Console.WriteLine("Число\tЧастота(старого массива)");
                    Console.WriteLine("----------------------------------");
                    foreach (var item in f)
                    {
                        Console.WriteLine($"{item.Key * item.Value}\t{item.Value}");
                    }
                }
                else
                {
                    Console.WriteLine("Файл не существует.");
                }
            }
            catch 
            {
                Console.WriteLine("Неверный формат");
            }
            Console.ReadKey();
        }
    }
}
