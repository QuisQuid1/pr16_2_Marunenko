﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace пр16_4
{
    internal class Country
    {
        public string name;
        public long population;
        public Country(string name, long population)
        {
            this.name = name;
            this.population = population;
        }   
    }
}
