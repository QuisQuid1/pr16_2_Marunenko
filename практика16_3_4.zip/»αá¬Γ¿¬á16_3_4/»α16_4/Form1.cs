﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace пр16_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Country> c=new List<Country>();
        private void button1_Click(object sender, EventArgs e)
        {
            if (File.Exists("text.txt"))
            {
                StreamReader sw = File.OpenText("text.txt");
                while (!sw.EndOfStream)
                {
                    string st = sw.ReadLine();
                    listBox1.Items.Add(st);
                }
                sw.Close();
            }
            else { MessageBox.Show("Файла нет"); }
            button1.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear(); 
            textBox1.Clear();
            button1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text.Replace(" ", " "), out int r))
            {
                long n = long.Parse(textBox1.Text.Replace(" ", " "));
                var sort=c.Where(cn=>cn.population>n).OrderBy(cn=>cn.name.Length).ToList();
                foreach (Country country in sort)
                {
                    listBox2.Items.Add(country.name + " " + country.population);
                }
                string[]lines=File.ReadAllLines("text.txt");
                foreach (string line in lines) 
                {
                    char d = line.First(cn => char.IsDigit(cn));
                    string[]p=line.Split(d);
                    string b = p[0];
                    string v = d + p[1];
                    long pop = long.Parse(v.Replace(" ", ""));
                    c.Add(new Country(b, pop));
                }
                var sort1 = c.OrderBy(cn => cn.name.Length);
                foreach (Country country in sort1)
                {
                    listBox2.Items.Add(country.name + " " + country.population);
                }
            }
        }
    }
}
